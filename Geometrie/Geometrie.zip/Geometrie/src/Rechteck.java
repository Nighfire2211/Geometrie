public class Rechteck
{
    private double breite,laenge;

    public Rechteck()
    {
        laenge=5;
        breite=7.5;
        getBreite();
        getLaenge();
        flaeche(breite,laenge);
        umfang(breite,laenge);

    }

    public Rechteck(double l,double b)
    {
        setBreite(b);
        setLaenge(l);
        getBreite();
        getLaenge();
        flaeche(b,l);
        umfang(b,l);

    }
    public double getBreite() {
        return breite;
    }

    public void setBreite(double breite) {
        this.breite = breite;
    }

    public double getLaenge() {
        return laenge;
    }

    public void setLaenge(double laenge) {
        this.laenge = laenge;
    }

    public void flaeche(double breite, double laenge)
    {
        double flaeche=breite*laenge;

        System.out.println("Die Fläche beträgt: "+flaeche);
    }
    public void umfang(double breite, double laenge)
    {
        double umfang =2*breite+2*laenge;

        System.out.println("Der Umfang beträgt: "+umfang);
    }
}

